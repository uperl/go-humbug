# pb33f spike findings

Versions: libopenapi v0.41.6, libopenapi-validator v0.16.1, jsonschema/v6 v6.0.3, Go 1.27.0.
All 20 fixtures (F01-F16 plus variants F04b, F05b, F06b, F15b) ran; outcomes match expectations
(`go test ./spike/...`). Raw captures: `testdata/expected/`. Only the public API was used.

## Recommendation: GO, wrapped

Use pb33f directly for *validation* and wrap it with a thin normalizer plus a separate
body source mapper. pb33f gives sound pass/fail, aggregated schema failures, and structured
`ErrorKind`s; it does not give body line/column or stable ordering.

## Answers to the open questions (section 10)

1. **Response independent of an invalid request?** Yes. `ValidateHttpResponse` needs only the
   request for routing. F16: request-only 1 error, response-only 1 error, combined 2 errors,
   so neither side suppresses the other. *Not tested:* combined validation when the route itself
   is unmatched (F15/F15b have no response); `ValidateHttpRequestResponse` returns the routing
   error only, by code reading, not by experiment.
2. **Source metadata from the spec, incl. external refs?** Partly. Top-level `SpecLine/SpecCol`
   are real spec positions: F14 resolves into `components.yaml` (4:7) but the **file name is not
   exposed**; `SchemaURL`/`Location` are synthetic hashes (`file:///.../6d6d63625287ac73#`) for
   most schemas. `SchemaValidationFailure.Line/Column` are **schema-local** offsets (F02 11:15, F14
   10:18), not spec or body positions. Don't use them.
3. **JSON instance paths without parsing English?** Yes for body schema errors:
   `SchemaValidationFailure.InstancePath []string`, `FieldPath` (`$.age`), `KeywordLocation`
   (`/properties/age/type`). Caveats: root-level failures have empty `FieldPath` (F10 required);
   parameter errors have `InstancePath=[name]` but empty `FieldPath` and a synthetic
   `/paths/.../parameters/limit/schema/maximum` keyword location (F05, F05b); F05b's query
   range error has empty `InstancePath`.
4. **oneOf no-match vs multi-match?** Distinguishable structurally, but only via the nested
   `OriginalJsonSchemaError` tree: the cause of kind `kind.OneOf` has `Subschemas []int`
   (empty = none matched, F11; `[0 1]` = ambiguous, F12). The flattened `Reason` text is the only
   other signal ("subschemas 0, 1 matched"). `anyOf` (F13) has no fields, only branch causes.
   Requires reflection or a type switch on `kind.*` (public, but keyword-specific).
5. **Reading/rewinding bodies?** The validator restores bodies: after request, response and
   combined validation, re-reading yielded identical bytes in every fixture (`bodyBytesIdenticalOnReread`).
   Not tested: very large/streaming bodies and gzip.
6. **Stable and deterministic?** Mostly. Across 5 runs, F03 (several failures in one body)
   changed the *order* of `SchemaValidationErrors` (seen: name/age/email vs age/email/name) but not
   the set. The top-level slice order is sorted by the library. Sidecar must sort schema failures
   itself (e.g. by KeywordLocation then InstancePath). Message wording was not compared separately.
7. **Proven by structure vs speculative?** Proven: failure category (`ValidationType/SubType`),
   parameter name, instance path, keyword, oneOf matched indexes, request vs response (by which
   call produced it; there is no provenance field on the error itself, though `ValidationType`
   is `requestBody`/`response` in practice). Speculative: "plausibly cascading" relations; the
   library neither links nor flags them.
8. **Protocol/taxonomy changes:** see below.

## Key behaviors

- **Aggregation (R5):** independent invalid fields in one body are returned together, in a single
  `ValidationError` with several `SchemaValidationFailure`s (F03: 3). Across areas
  (path param + query, F05b) they are separate errors. Header, parameter, body and response checks
  run independently; only the body *parse* failure (F08) stops schema checks for that body.
- **Cascades:** a type mismatch on an object (F04b `profile: "oops"`) yields only the type error;
  no redundant `required` errors. In F10, though, one response yields both `missing 'name'`
  (root) and `id` type, which are genuinely independent.
- **Composition:** `oneOf`/`anyOf` produce one `SchemaValidationFailure` **per leaf branch failure**
  (F11: 4 failures for 2 branches), each repeating the *entire* cause tree. Grouping by branch
  must be rebuilt from `KeywordLocation` (`/oneOf/0/$ref/required`) or the tree. Don't treat these
  4 as independently actionable.
- **Operation matching:** unmatched path = `path/missing`, unmatched method = `path/missingOperation`;
  both have SpecLine -1.
- **Media type (F07):** `requestBody/contentType`, no schema errors. **Undocumented status (F09):**
  `response/statusCode`, with the operation's spec line.
- **Malformed JSON (F08):** `requestBody/schema`, `SpecLine=0`, no schema failures; the parse
  error exists only inside `Reason` text (`invalid character ',' ...`). **No byte/line/column.**
  Parsing the text would be required; avoid by running our own JSON parser first.

## R1: spec loading (probed)

| Input | Result |
|---|---|
| OpenAPI 3.0.3, 3.1.0, 3.2.0 | loads and `ValidateDocument` passes (empty `paths`) |
| Swagger 2.0 | rejected: `different version (oas2)`; validator construction fails |
| Unresolvable `$ref` | `BuildV3Model` returns an error (`component ... does not exist`); a slog ERROR line is also written to stderr; `ValidateDocument` still reports valid. Reference errors must be read from model build, not ValidateDocument |
| External file `$ref` | works only with `DocumentConfiguration{BasePath, AllowFileReferences:true}` |

Only 3.1 request/response behavior was exercised; 3.0 vs 3.1 *transaction* differences (nullable,
exclusiveMinimum) are untested.

## Error mapping (observed -> proposed, provisional)

| Fixture | pb33f (`Type/SubType`) | Proposed code | Text parsing needed? |
|---|---|---|---|
| F02-F04, F14 | requestBody/schema + SVF.KeywordLocation | `schema.type`, `schema.required`, `schema.minimum` ... derived from last keyword segment | No |
| F05, F05b | parameter/query, parameter/path | `parameter.invalid` | No (name in `ParameterName`); decoded value only in text |
| F06 | parameter/header | `parameter.missing` vs F06b `parameter.invalid` | **Yes**: missing vs invalid-value is `Message`/keyword `/required` vs `/minLength` |
| F07 | requestBody/contentType | `body.media_type_unsupported` | No |
| F08 | requestBody/schema (no failures) | `body.malformed` | **Yes** to tell it apart from F02: only `SpecLine==0 && no SVF` |
| F09 | response/statusCode | `response.status_undocumented` | No |
| F10 | response/schema | `schema.*` with response provenance | No |
| F11 | requestBody/schema, OneOf cause | `schema.oneOf.no_match` + child branches | No (kind tree) |
| F12 | same, OneOf.Subschemas=[0 1] | `schema.oneOf.ambiguous` | No (kind tree) |
| F13 | AnyOf cause | `schema.anyOf.no_match` | No |
| F15 / F15b | path/missing, path/missingOperation | `operation.not_found` / `operation.method_not_allowed` | No |

## What a source mapper must do

pb33f exposes no body positions. A mapper must re-parse the **original body bytes** with a
position-tracking JSON parser and resolve `InstancePath` to byte/line/column. Missing-property
errors (F04) point at the parent (`$.profile`); the mapper must decide how to report the absent
child. Parameter and header errors need the original URL/header text, which the validator
doesn't echo.

## Suggested protocol/taxonomy changes

- Add an explicit `side: request|response` set by the sidecar per call (not inferred from library output).
- Define `instance` as a JSON Pointer built from `InstancePath` (library gives raw segments, not RFC 6901 escaped; escape `~` and `/`).
- Treat `schema.*` composition failures as a **group** (parent oneOf/anyOf + children) rather than flat diagnostics.
- Reserve `location.body` as optional; absent for F08-style parse errors unless our own parser supplies it.
- Sort diagnostics (side, type, instance, keyword) before emitting; don't rely on library order.
- Record a spec-location field with an optional (unknown) file name; don't promise it.

## Gaps / not done

3.0-vs-3.1 transaction differences, cookies, arrays, `allOf`, binary bodies, repeated headers,
very large bodies, unmatched-route combined validation, and wording-stability comparison were not covered.
