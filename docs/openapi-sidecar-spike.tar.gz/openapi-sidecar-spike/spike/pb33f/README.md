# pb33f validator spike

Throwaway Go harness for `docs/openapi-sidecar-pb33f-spike-requirements.md`.
Dependencies are pinned in `go.mod` (libopenapi v0.41.6, libopenapi-validator v0.16.1, jsonschema/v6 v6.0.3). Go 1.27 was used.

```sh
go run ./spike/pb33f -all                          # run F01-F16 matrix, one summary line per case
go run ./spike/pb33f -case F11                     # one case, full raw JSON capture on stdout
go run ./spike/pb33f -all -out testdata/expected   # regenerate raw captures
go run ./spike/pb33f -spec path/to/other.yaml      # R1: load/validate a spec only
go test ./spike/...                                # automated expectations
```

Layout: `testdata/specs/` (OpenAPI 3.1 + external `components.yaml`), `testdata/cases/cases.json`
(all fixtures, request/response as data), `testdata/expected/*.json` (raw captures: every
`ValidationError` field, `SchemaValidationFailure`, and the nested `jsonschema.ValidationError`
tree with concrete `ErrorKind` type and its exported fields). Findings: `findings.md`.
