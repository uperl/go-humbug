// Command pb33f is a throwaway spike exercising pb33f/libopenapi-validator
// against the F01-F16 fixture matrix and dumping raw diagnostic structure.
//
//	go run ./spike/pb33f -all -out testdata/expected
//	go run ./spike/pb33f -case F02
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"

	"github.com/pb33f/jsonschema/v6"
	"github.com/pb33f/libopenapi"
	validator "github.com/pb33f/libopenapi-validator"
	verrors "github.com/pb33f/libopenapi-validator/errors"
	"github.com/pb33f/libopenapi/datamodel"
)

type Case struct {
	ID     string `json:"id"`
	Desc   string `json:"desc"`
	Expect string `json:"expect"` // valid | request-invalid | response-invalid | both-invalid
	Note   string `json:"note,omitempty"`
	Req    Msg    `json:"req"`
	Res    *Msg   `json:"res,omitempty"`
}

type Msg struct {
	Method  string            `json:"method,omitempty"`
	URL     string            `json:"url,omitempty"`
	Status  int               `json:"status,omitempty"`
	Headers map[string]string `json:"headers,omitempty"`
	Body    string            `json:"body,omitempty"`
}

// RawErr is a lossless-as-possible dump of *verrors.ValidationError.
type RawErr struct {
	Message           string          `json:"message"`
	Reason            string          `json:"reason"`
	ValidationType    string          `json:"validationType"`
	ValidationSubType string          `json:"validationSubType"`
	SpecLine          int             `json:"specLine"`
	SpecCol           int             `json:"specCol"`
	HowToFix          string          `json:"howToFix"`
	RequestPath       string          `json:"requestPath"`
	SpecPath          string          `json:"specPath"`
	RequestMethod     string          `json:"requestMethod"`
	ParameterName     string          `json:"parameterName,omitempty"`
	ContextType       string          `json:"contextType,omitempty"`
	Schema            []RawSchemaFail `json:"schemaValidationErrors,omitempty"`
}

type RawSchemaFail struct {
	Reason          string   `json:"reason"`
	InstancePath    []string `json:"instancePath"`
	FieldName       string   `json:"fieldName"`
	FieldPath       string   `json:"fieldPath"`
	KeywordLocation string   `json:"keywordLocation"`
	Line            int      `json:"line"`
	Column          int      `json:"column"`
	ReferenceSchema string   `json:"referenceSchemaPresent,omitempty"`
	Original        *RawJS   `json:"originalJsonSchemaError,omitempty"`
}

// RawJS is the nested jsonschema.ValidationError tree (the only place nested
// branch errors survive).
type RawJS struct {
	SchemaURL        string         `json:"schemaURL"`
	InstanceLocation []string       `json:"instanceLocation"`
	KindType         string         `json:"kindType"`
	KeywordPath      []string       `json:"keywordPath"`
	KindFields       map[string]any `json:"kindFields,omitempty"`
	Causes           []*RawJS       `json:"causes,omitempty"`
}

type SideResult struct {
	Valid        bool     `json:"valid"`
	Errors       []RawErr `json:"errors"`
	BodyConsumed bool     `json:"bodyConsumedAfterValidation"`
	BodyRestored bool     `json:"bodyBytesIdenticalOnReread"`
}

type CaseResult struct {
	Case          Case        `json:"case"`
	RequestOnly   SideResult  `json:"requestOnly"`
	ResponseOnly  *SideResult `json:"responseOnly,omitempty"`
	Combined      *SideResult `json:"combined,omitempty"`
	Outcome       string      `json:"outcome"` // derived from requestOnly/responseOnly
	Matches       bool        `json:"matchesExpectation"`
	Deterministic bool        `json:"deterministicAcross5Runs"`
	OrderStable   bool        `json:"orderStableAcross5Runs"`
}

func dumpJS(e *jsonschema.ValidationError) *RawJS {
	if e == nil {
		return nil
	}
	r := &RawJS{SchemaURL: e.SchemaURL, InstanceLocation: e.InstanceLocation}
	if e.ErrorKind != nil {
		r.KindType = fmt.Sprintf("%T", e.ErrorKind)
		r.KeywordPath = e.ErrorKind.KeywordPath()
		r.KindFields = kindFields(e.ErrorKind)
	}
	for _, c := range e.Causes {
		r.Causes = append(r.Causes, dumpJS(c))
	}
	return r
}

// kindFields reflects the exported fields of the concrete ErrorKind (e.g.
// kind.OneOf.Subschemas) so structured data is captured, not message text.
func kindFields(k jsonschema.ErrorKind) map[string]any {
	v := reflect.ValueOf(k)
	for v.Kind() == reflect.Ptr {
		v = v.Elem()
	}
	if v.Kind() != reflect.Struct {
		return nil
	}
	out := map[string]any{}
	for i := 0; i < v.NumField(); i++ {
		if f := v.Type().Field(i); f.IsExported() {
			out[f.Name] = v.Field(i).Interface()
		}
	}
	if len(out) == 0 {
		return nil
	}
	return out
}

func dump(errs []*verrors.ValidationError) []RawErr {
	out := []RawErr{}
	for _, e := range errs {
		r := RawErr{
			Message: e.Message, Reason: e.Reason, ValidationType: e.ValidationType,
			ValidationSubType: e.ValidationSubType, SpecLine: e.SpecLine, SpecCol: e.SpecCol,
			HowToFix: e.HowToFix, RequestPath: e.RequestPath, SpecPath: e.SpecPath,
			RequestMethod: e.RequestMethod, ParameterName: e.ParameterName,
		}
		if e.Context != nil {
			r.ContextType = fmt.Sprintf("%T", e.Context)
		}
		for _, s := range e.SchemaValidationErrors {
			f := RawSchemaFail{
				Reason: s.Reason, InstancePath: s.InstancePath, FieldName: s.FieldName,
				FieldPath: s.FieldPath, KeywordLocation: s.KeywordLocation,
				Line: s.Line, Column: s.Column, Original: dumpJS(s.OriginalJsonSchemaError),
			}
			if s.ReferenceSchema != "" {
				f.ReferenceSchema = "yes"
			}
			r.Schema = append(r.Schema, f)
		}
		out = append(out, r)
	}
	return out
}

func buildReq(m Msg) *http.Request {
	var body io.Reader
	if m.Body != "" {
		body = strings.NewReader(m.Body)
	}
	r := httptest.NewRequest(m.Method, "http://example.test"+m.URL, body)
	for k, v := range m.Headers {
		r.Header.Set(k, v)
	}
	return r
}

func buildRes(m Msg, req *http.Request) *http.Response {
	r := &http.Response{
		StatusCode: m.Status, Status: fmt.Sprintf("%d", m.Status), Proto: "HTTP/1.1",
		Header: http.Header{}, Body: io.NopCloser(strings.NewReader(m.Body)), Request: req,
	}
	for k, v := range m.Headers {
		r.Header.Set(k, v)
	}
	return r
}

// bodyState reports whether the body was drained and whether a re-read yields
// the original bytes (R7).
func bodyState(rc io.ReadCloser, orig string) (consumed, identical bool) {
	if rc == nil {
		return false, orig == ""
	}
	b, _ := io.ReadAll(rc)
	return len(b) == 0 && orig != "", string(b) == orig
}

func runCase(v validator.Validator, c Case) CaseResult {
	res := CaseResult{Case: c}
	req := buildReq(c.Req)
	ok, errs := v.ValidateHttpRequest(req)
	cons, ident := bodyState(req.Body, c.Req.Body)
	res.RequestOnly = SideResult{Valid: ok, Errors: dump(errs), BodyConsumed: cons, BodyRestored: ident}

	reqInvalid := !ok
	resInvalid := false
	if c.Res != nil {
		req2 := buildReq(c.Req)
		resp := buildRes(*c.Res, req2)
		ok, errs := v.ValidateHttpResponse(req2, resp)
		cons, ident := bodyState(resp.Body, c.Res.Body)
		res.ResponseOnly = &SideResult{Valid: ok, Errors: dump(errs), BodyConsumed: cons, BodyRestored: ident}
		resInvalid = !ok

		req3 := buildReq(c.Req)
		resp3 := buildRes(*c.Res, req3)
		ok, errs = v.ValidateHttpRequestResponse(req3, resp3)
		cons, ident = bodyState(resp3.Body, c.Res.Body)
		res.Combined = &SideResult{Valid: ok, Errors: dump(errs), BodyConsumed: cons, BodyRestored: ident}
	}
	switch {
	case reqInvalid && resInvalid:
		res.Outcome = "both-invalid"
	case reqInvalid:
		res.Outcome = "request-invalid"
	case resInvalid:
		res.Outcome = "response-invalid"
	default:
		res.Outcome = "valid"
	}
	res.Matches = res.Outcome == c.Expect

	// R8: determinism over 5 runs.
	base := fingerprint(res)
	res.Deterministic, res.OrderStable = true, true
	for i := 0; i < 4; i++ {
		again := runOnce(v, c)
		if !reflect.DeepEqual(sorted(base), sorted(again)) {
			res.Deterministic = false
		}
		if !reflect.DeepEqual(base, again) {
			res.OrderStable = false
		}
	}
	return res
}

func runOnce(v validator.Validator, c Case) []string {
	req := buildReq(c.Req)
	_, errs := v.ValidateHttpRequest(req)
	out := fp(errs)
	if c.Res != nil {
		req2 := buildReq(c.Req)
		_, e2 := v.ValidateHttpResponse(req2, buildRes(*c.Res, req2))
		out = append(out, fp(e2)...)
	}
	return out
}

func fingerprint(r CaseResult) []string {
	var out []string
	add := func(s *SideResult) {
		if s == nil {
			return
		}
		for _, e := range s.Errors {
			out = append(out, errFP(e))
		}
	}
	add(&r.RequestOnly)
	add(r.ResponseOnly)
	return out
}

func fp(errs []*verrors.ValidationError) []string {
	var out []string
	for _, e := range dump(errs) {
		out = append(out, errFP(e))
	}
	return out
}

// errFP is the semantic fingerprint: everything except wording-ish fields.
func errFP(e RawErr) string {
	var sb strings.Builder
	fmt.Fprintf(&sb, "%s/%s|%s|%d:%d", e.ValidationType, e.ValidationSubType, e.ParameterName, e.SpecLine, e.SpecCol)
	for _, s := range e.Schema {
		fmt.Fprintf(&sb, "|%s@%s", s.KeywordLocation, s.FieldPath)
	}
	return sb.String()
}

func sorted(s []string) []string {
	c := append([]string(nil), s...)
	sort.Strings(c)
	return c
}

func main() {
	specPath := flag.String("spec", "testdata/specs/users.yaml", "OpenAPI spec")
	casesPath := flag.String("cases", "testdata/cases/cases.json", "cases file")
	only := flag.String("case", "", "run a single case id")
	all := flag.Bool("all", false, "run all cases")
	out := flag.String("out", "", "write per-case JSON captures to this dir")
	flag.Parse()

	raw, err := os.ReadFile(*specPath)
	check(err)
	abs, _ := filepath.Abs(filepath.Dir(*specPath))
	doc, err := libopenapi.NewDocumentWithConfiguration(raw, &datamodel.DocumentConfiguration{
		BasePath: abs, AllowFileReferences: true,
	})
	check(err)
	fmt.Printf("# spec: %s  version=%s\n", *specPath, doc.GetSpecInfo().Version)
	if _, errs := doc.BuildV3Model(); errs != nil {
		fmt.Printf("# model build errors: %v\n", errs)
	}
	v, verrs := validator.NewValidator(doc)
	if len(verrs) > 0 {
		fmt.Printf("# validator construction errors: %v\n", verrs)
		os.Exit(1)
	}
	ok, derrs := v.ValidateDocument()
	fmt.Printf("# ValidateDocument (spec-level, separate from transactions): valid=%v errs=%d\n", ok, len(derrs))

	cb, err := os.ReadFile(*casesPath)
	check(err)
	var cases []Case
	check(json.Unmarshal(cb, &cases))

	if *out != "" {
		check(os.MkdirAll(*out, 0o755))
	}
	fail := 0
	for _, c := range cases {
		if *only != "" && c.ID != *only {
			continue
		}
		if *only == "" && !*all {
			continue
		}
		r := runCase(v, c)
		mark := "ok  "
		if !r.Matches {
			mark = "FAIL"
			fail++
		}
		fmt.Printf("%s %-5s expect=%-16s got=%-16s req=%d res=%d comb=%d det=%v order=%v  %s\n",
			mark, c.ID, c.Expect, r.Outcome, len(r.RequestOnly.Errors), nOf(r.ResponseOnly), nOf(r.Combined),
			r.Deterministic, r.OrderStable, c.Desc)
		b, _ := json.MarshalIndent(r, "", "  ")
		if *out != "" {
			check(os.WriteFile(filepath.Join(*out, c.ID+".json"), append(b, '\n'), 0o644))
		} else if *only != "" {
			fmt.Println(string(bytes.TrimSpace(b)))
		}
	}
	if fail > 0 {
		os.Exit(2)
	}
}

func nOf(s *SideResult) int {
	if s == nil {
		return -1
	}
	return len(s.Errors)
}

func check(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}
