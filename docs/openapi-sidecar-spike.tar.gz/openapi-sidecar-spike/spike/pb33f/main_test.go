package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/pb33f/libopenapi"
	validator "github.com/pb33f/libopenapi-validator"
	"github.com/pb33f/libopenapi/datamodel"
)

const root = "../../testdata"

func load(t *testing.T) (validator.Validator, []Case) {
	t.Helper()
	raw, err := os.ReadFile(filepath.Join(root, "specs/users.yaml"))
	if err != nil {
		t.Fatal(err)
	}
	abs, _ := filepath.Abs(filepath.Join(root, "specs"))
	doc, err := libopenapi.NewDocumentWithConfiguration(raw, &datamodel.DocumentConfiguration{BasePath: abs, AllowFileReferences: true})
	if err != nil {
		t.Fatal(err)
	}
	v, errs := validator.NewValidator(doc)
	if len(errs) > 0 {
		t.Fatal(errs)
	}
	cb, _ := os.ReadFile(filepath.Join(root, "cases/cases.json"))
	var cases []Case
	if err := json.Unmarshal(cb, &cases); err != nil {
		t.Fatal(err)
	}
	return v, cases
}

// TestMatrix asserts each fixture's outcome class and the key structural
// properties the findings rely on. Known library limitations are asserted
// as-is (not "fixed") so a library upgrade that changes them fails loudly.
func TestMatrix(t *testing.T) {
	v, cases := load(t)
	by := map[string]CaseResult{}
	for _, c := range cases {
		r := runCase(v, c)
		by[c.ID] = r
		t.Run(c.ID, func(t *testing.T) {
			if !r.Matches {
				t.Errorf("outcome %s, want %s", r.Outcome, c.Expect)
			}
			if !r.RequestOnly.BodyRestored {
				t.Errorf("request body not restored after validation")
			}
			if r.ResponseOnly != nil && !r.ResponseOnly.BodyRestored {
				t.Errorf("response body not restored after validation")
			}
		})
	}

	// R5: independent fields in one body are aggregated into one ValidationError.
	if n := len(by["F03"].RequestOnly.Errors[0].Schema); n != 3 {
		t.Errorf("F03: want 3 schema failures in one error, got %d", n)
	}
	// F04b: type mismatch does not also emit nested required errors.
	if n := len(by["F04b"].RequestOnly.Errors[0].Schema); n != 1 {
		t.Errorf("F04b: want 1 failure, got %d", n)
	}
	// R4: response validates independently of an invalid request; combined = both.
	f16 := by["F16"]
	if f16.ResponseOnly == nil || f16.ResponseOnly.Valid || len(f16.Combined.Errors) != 2 {
		t.Errorf("F16: independent/combined results unexpected")
	}
	// F12 vs F11: OneOf multi-match distinguishable only via kind fields.
	f12 := by["F12"].RequestOnly.Errors[0].Schema[0].Original.Causes[0]
	if kf := f12.KindFields["Subschemas"]; kf == nil {
		t.Errorf("F12: expected OneOf.Subschemas populated, got %v", f12.KindFields)
	}
	f11 := by["F11"].RequestOnly.Errors[0].Schema[0].Original.Causes[0]
	if kf, ok := f11.KindFields["Subschemas"].([]int); !ok || len(kf) != 0 {
		t.Errorf("F11: expected empty OneOf.Subschemas (no match), got %v", f11.KindFields)
	}
	// R6 limitation: body parse error carries no byte/line/column.
	if e := by["F08"].RequestOnly.Errors[0]; e.SpecLine != 0 || len(e.Schema) != 0 {
		t.Errorf("F08: library now exposes location data; revisit findings: %+v", e)
	}
}
